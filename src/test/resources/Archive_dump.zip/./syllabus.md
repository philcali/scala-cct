# Syllabus
## What to expect
 * Quizzes
 * Tests
 * Owned